<?php

class Ghost_Exception extends Exception {
  
}
